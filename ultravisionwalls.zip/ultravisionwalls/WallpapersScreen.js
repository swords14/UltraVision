import React, { useState } from 'react';
import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity, Modal, Dimensions } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

const WallpapersScreen = ({ route }) => {
  const { category } = route.params;
  const [selectedImage, setSelectedImage] = useState(null);
  const [isFullScreen, setIsFullScreen] = useState(false);

  const wallpapersData = {
    Shounen: [
      { id: 1, image: 'https://images3.alphacoders.com/134/thumb-1920-1347142.png' },
      { id: 2, image: 'https://w0.peakpx.com/wallpaper/586/759/HD-wallpaper-sasuke-rinnegan-anime-eye-galaxy-iphone-naruto-pixel-purple-susuke-uchiha.jpg' },
    ],
    Shoujo: [
      { id: 1, image: 'https://images3.alphacoders.com/134/1349741.png' },
      { id: 2, image: 'https://assets.teenvogue.com/photos/609543e43c6dabf2aad2385c/16:9/w_1280,c_limit/SailorMoonEternalTheMovie_Main_Part2_Vertical_RGB_PRE_EN-US.jpeg' },
    ],
    ShoujoAi: [
      { id: 1, image: 'https://i.ytimg.com/vi/yao9ww00ul4/maxresdefault.jpg' },
      { id: 2, image: 'https://wallpapercosmos.com/w/full/9/5/1/117606-3840x2160-desktop-4k-your-name-background.jpg' },
    ],
  };

  const wallpapers = wallpapersData[category.id] || [];

  const handleImagePress = (image) => {
    setSelectedImage(image);
    toggleFullScreen();
  };

  const toggleFullScreen = () => {
    setIsFullScreen(!isFullScreen);
  };

  const handleDownload = () => {
    // Lógica para baixar a imagem
  };

  const handleReport = () => {
    // Lógica para reportar a imagem
  };

  const handleShare = () => {
    // Lógica para compartilhar a imagem
  };

  return (
    <View style={styles.container}>
      {isFullScreen && (
        <Modal visible={isFullScreen} transparent>
          <View style={styles.modalContainer}>
            <TouchableOpacity onPress={toggleFullScreen} style={styles.closeButton}>
              <MaterialIcons name="close" size={30} color="#fff" />
            </TouchableOpacity>
            <Image source={{ uri: selectedImage }} style={styles.fullScreenImage} />
            <View style={styles.actionsContainer}>
              <TouchableOpacity onPress={handleDownload}>
                <MaterialIcons name="file-download" size={30} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity onPress={handleReport}>
                <MaterialIcons name="report" size={30} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity onPress={handleShare}>
                <MaterialIcons name="share" size={30} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
      {!isFullScreen && (
        <>
          <Text style={styles.title}>Papéis de Parede - {category.name}</Text>
          <FlatList
            data={wallpapers}
            keyExtractor={(item) => item.id.toString()}
            numColumns={2}
            renderItem={({ item }) => (
              <TouchableOpacity onPress={() => handleImagePress(item.image)} style={styles.imageContainer}>
                <Image source={{ uri: item.image }} style={styles.wallpaperImage} />
              </TouchableOpacity>
            )}
          />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
    textAlign: 'center',
  },
  imageContainer: {
    flex: 1,
    margin: 5,
  },
  wallpaperImage: {
    width: Dimensions.get('window').width / 2 - 20,
    height: 200,
    borderRadius: 10,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
 fullScreenImage:{
width:'100%',
height:'100%',
resizeMode:'contain'
},
closeButton:{
position:'absolute',
top:'5%',
right:'5%'
},
actionsContainer:{
flexDirection:'row',
justifyContent:'space-around',
position:'absolute',
bottom:'5%',
width:'100%'
}
});

export default WallpapersScreen;