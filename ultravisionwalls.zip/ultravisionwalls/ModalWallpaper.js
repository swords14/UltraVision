// ModalWallpaper.js
import React from 'react';
import { Modal, View, Text, Image, StyleSheet, TouchableOpacity, Share, Alert } from 'react-native';
import { AntDesign, MaterialIcons } from '@expo/vector-icons';

const ModalWallpaper = ({ visible, onClose, wallpaper }) => {
  if (!visible || !wallpaper) {
    return null;
  }

  const handleDownload = () => {
    // Adicione lógica para fazer o download da imagem
    Alert.alert('Download', 'Imagem baixada com sucesso!');
  };

  const handleShare = async () => {
    try {
      const result = await Share.share({
        message: 'Confira este papel de parede:',
        url: wallpaper.imageUri,
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // Compartilhado com sucesso
          console.log(`Compartilhado com sucesso via ${result.activityType}`);
        } else {
          // Compartilhado com sucesso
          console.log('Compartilhado com sucesso');
        }
      } else if (result.action === Share.dismissedAction) {
        // Compartilhamento cancelado
        console.log('Compartilhamento cancelado');
      }
    } catch (error) {
      console.error('Erro ao compartilhar', error.message);
    }
  };

  const handleReport = () => {
    // Adicione lógica para reportar o wallpaper
    Alert.alert('Reportar', 'Este wallpaper foi reportado com sucesso. Agradecemos seu feedback!');
  };

  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={onClose}
    >
      <View style={styles.modalContainer}>
        <Image source={{ uri: wallpaper.imageUri }} style={styles.wallpaperImage} />
        <View style={styles.optionsContainer}>
          <TouchableOpacity style={styles.optionButton} onPress={handleDownload}>
            <AntDesign name="download" size={24} color="#fff" />
            <Text style={styles.optionText}>Baixar</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.optionButton} onPress={handleShare}>
            <AntDesign name="sharealt" size={24} color="#fff" />
            <Text style={styles.optionText}>Compartilhar</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.optionButton} onPress={handleReport}>
            <AntDesign name="warning" size={24} color="#fff" />
            <Text style={styles.optionText}>Reportar</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={styles.closeButton} onPress={onClose}>
          <MaterialIcons name="close" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: '#000',
  },
  wallpaperImage: {
    flex: 1,
    resizeMode: 'contain',
  },
  optionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    position: 'absolute',
    bottom: 30,
    left: 0,
    right: 0,
  },
  optionButton: {
    alignItems: 'center',
  },
  optionText: {
    color: '#fff',
    marginTop: 5,
  },
  closeButton: {
    position: 'absolute',
    top: 30,
    right: 20,
    padding: 10,
    zIndex: 1,
  },
});

export default ModalWallpaper;
