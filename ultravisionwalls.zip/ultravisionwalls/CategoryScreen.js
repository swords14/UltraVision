import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, TextInput, StyleSheet, ImageBackground } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

const CategoryScreen = ({ navigation }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const categories = [
    { id: 'Shounen', name: 'Shounen', subtitle: '', color: '#65a98c', image: 'https://example.com/nature.jpg' },
    { id: 'Shoujo', name: 'Shoujo', subtitle: '', color: '#f5b971', image: 'https://example.com/animals.jpg' },
    { id: 'ShoujoAi', name: 'Shoujo Ai', subtitle: '', color: '#6fa4d4', image: 'https://example.com/abstract.jpg' },
  ];
  const [categoryImages, setCategoryImages] = useState({});

  useEffect(() => {
    const loadCategoryImages = async () => {
      const images = {};
      for (const category of categories) {
        const response = await fetch(category.image);
        const imageData = await response.blob();
        images[category.id] = URL.createObjectURL(imageData);
      }
      setCategoryImages(images);
    };

    loadCategoryImages();
  }, [categories]);

  const handleCategoryPress = (category) => {
    navigation.navigate('WallpapersScreen', { category });
  };

  const handleSearch = () => {
    alert(`Pesquisar por: ${searchQuery}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Explore Categorias</Text>
        <View style={styles.searchContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="Pesquisar"
            placeholderTextColor="#888"
            value={searchQuery}
            onChangeText={(text) => setSearchQuery(text)}
            onSubmitEditing={handleSearch}
          />
          <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
            <MaterialIcons name="search" size={24} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
      <FlatList
        data={categories}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.categoryItem, { backgroundColor: item.color }]}
            onPress={() => handleCategoryPress(item)}
          >
            <ImageBackground
              source={{ uri: categoryImages[item.id] }}
              style={styles.categoryImage}
              imageStyle={styles.imageOverlay}
            >
              <Text style={styles.categoryName}>{item.name}</Text>
              <Text style={styles.categorySubtitle}>{item.subtitle}</Text>
            </ImageBackground>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 20,
  },
  header: {
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 15,
    backgroundColor: '#fff',
    marginRight: 10,
  },
  searchButton: {
    padding: 15,
    backgroundColor: '#3498db',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryItem: {
    borderRadius: 15,
    marginBottom: 15,
    overflow: 'hidden',
    elevation: 5,
  },
  categoryImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'flex-end',
    padding: 15,
  },
  imageOverlay: {
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
  },
  categoryName: {
    fontSize: 24,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 5,
  },
  categorySubtitle: {
    fontSize: 16,
    color: '#fff',
  },
});

export default CategoryScreen;